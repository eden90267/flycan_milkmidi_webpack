export function foo() {
  return 'foo';
}

export default { name: 'milkmidi' };
