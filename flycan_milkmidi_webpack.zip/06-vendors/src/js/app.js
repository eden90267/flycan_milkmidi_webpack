// const _ = require('lodash');
// const $ = require('jquery');

import { foo } from '../libs/mylib';
console.log('app.js');
console.log(jQuery);
console.log(foo());