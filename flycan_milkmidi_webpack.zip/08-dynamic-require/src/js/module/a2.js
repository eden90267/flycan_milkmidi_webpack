module.exports = function () {
  console.log('a2');
}