require('../css/app.scss');

console.log('-------- app.js ---------');
console.log(process.env.NODE_ENV);

document.querySelector('button').addEventListener('click', () => {
  console.log('click');
});
if (process.env.NODE_ENV === 'development') {
  require('./app.dev');
}
