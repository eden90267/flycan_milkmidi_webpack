export function hello() {
  console.log('c.js');
}