export function hello() {
  console.log('a.js');
}