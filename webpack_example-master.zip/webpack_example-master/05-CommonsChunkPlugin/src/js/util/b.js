export function hello() {
  console.log('b.js');
}