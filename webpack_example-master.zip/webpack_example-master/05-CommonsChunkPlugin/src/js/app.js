import a from './util/a';
a.hello();

import b from './util/b';
b.hello();

import c from './util/c';
c.hello();