import React, { Component } from 'react';

export default class Main extends Component {
  constructor(props) {
    super(props);
    this.state = {
      label: 'milkmidi',
    };
    this.clickHandler = this.clickHandler.bind(this);
  }
  clickHandler() {
    this.setState({
      label: `click${Date.now()}`,
    });
  }
  render() {
    const { label } = this.state;
    return (
      <div className="main-root">
        <h1>hi, react</h1>
        <p>{label}</p>
        <button onClick={this.clickHandler}>click me</button>
      </div>
    );
  }
}
