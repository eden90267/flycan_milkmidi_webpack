import Vue from 'vue';
import App from '@/component/App';

export default new Vue({
  el: '#app',
  render: h => h(App),
});
