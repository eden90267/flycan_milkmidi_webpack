var name = 'milkmidi';
/**
 * @param {number} num1
 * @param {number} num2
 * @return {number}
 */
function add(num1, num2) {
  return num1 + num2;
}

/**
 * @return {string} name
 */
function getName() {
  return name;
}
module.exports = {
  add,
  getName,
};