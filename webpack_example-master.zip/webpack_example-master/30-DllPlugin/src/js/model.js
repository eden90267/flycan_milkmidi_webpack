// model.js
export function init() {
  console.log('init');
}