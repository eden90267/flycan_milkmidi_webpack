export const foo = (value) => {
  console.log(value);
}