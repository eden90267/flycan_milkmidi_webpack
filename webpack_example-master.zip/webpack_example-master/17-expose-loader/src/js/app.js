import '../html/index.html';
import $ from 'jquery';
import '../lib/jquery.scrollPosition';

$(()=>{
  $(window).milkmidi();
});