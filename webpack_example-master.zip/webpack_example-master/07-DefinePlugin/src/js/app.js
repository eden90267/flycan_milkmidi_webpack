console.log(DEF_BOO);
console.log(DEF_NUM);
// console.log(DEF_STR);
console.log(DEF_OBJ);
console.log(MY_TEXT);
console.log(WEB_URL);