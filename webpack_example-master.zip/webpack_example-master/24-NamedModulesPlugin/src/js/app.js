const { foo } = require('../libs/mylib')
console.log(foo());
console.log('app.js');
console.log(jQuery);



// const { add2 } = require('./util');