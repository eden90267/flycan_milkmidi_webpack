const age = 18;
const setting = {
  name: 'milkmidi',
  age,
  amount: 100,
};
module.exports = setting;
// export default setting;